@include('layouts.header.front-end')
    <div class="maindiv">
        <div class="btn-div">
            <h1>Product Details</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam, purus sitsit amet <br>, consectetur
                adipiscing elit ut aliquam, purus sit</p>
            <!-- <a class="box-btn">Our Services</a>
                <a class="border-btn">Contact Us </a> -->

        </div>

    </div>
    <section class="main-sec">
        <div class="appointment-div">
            <h1>Book An Appointment</h1>
            <textarea name="description" id="description" cols="30" rows="10"></textarea>
            <div class="image-drop">
                <img src="{{ asset('images')}}/image/Upload icon.png" height="50" alt="">
                <h3>Drop you image here </h3>
                <button>Choose File</button>
            </div>
            <h5>Select Vendor</h5>
            <input type="text" placeholder="Search the Vendor Name" class="search-input" id="vendor-search">
            <div id="vendor-list">

            </div>

            <button class="last-btn" id="submit-issue">Submit</button>
        </div>
        <div class="history-details">
        <div class="d-flex justify-content-center">
            <div class="spinner-border"
                 role="status" id="loading">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
            <div class="img-div-details">
                <div id="product-details-data">
               </div>
                <div class="befor">
                    <div class="div">

                    </div>
                    <h2>History</h2>
                </div>
                <div class="history-main-details" id="assign-history">


                </div>

            </div>

        </div>
    </section>
    <section class="footers">

        <div class="footer-first-div">
            <h1>LOGO</h1>
            <p>The world’s first and largest digital marketplace for crypto <br> collectibles and non-fungible tokens
                (NFTs).
                Buy, sell, and <br> discover exclusive digital assets. Ut enim ad minima veniam, quis <br> nostrum
                exercitationem
                ullam corporis suscipit laboriosam, nisi ut <br> aliquid ex ea commodi consequatur</p>
            <h6>Call Us:</h6>
            <h4 style="color: #6759FF;">
                +01 234 567 89
            </h4>
        </div>
        <div class="footer-second-div">

            <ul>

                <li style="font-family: 'Lato'sans-serif;
                       font-style: normal;
                       font-weight: 700;
                       font-size: 20px;
                       color: #6759FF;"> Menu Links</li>

                <li>Home </li>
                <li>Service</li>
                <li>About US </li>
                <li>Tarot Cards</li>
                <li>Blog</li>
            </ul>
        </div>
        <div class="footer-third-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                        font-style: normal;
                        font-weight: 700;
                        font-size: 20px;
                        color: #6759FF;"> Services</li>

                <li>Blog</li>
                <li>Refrigerator</li>
                <li>Mobile</li>
                <li>Laptop</li>
                <li>Blender</li>
                <li>Air purifier</li>
            </ul>
        </div>
        <div class="footer-four-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                        font-style: normal;
                        font-weight: 700;
                        font-size: 20px;
                        color: #6759FF;"> Contact info</li>

                <li>Collarado Demos
                    Beach, <br> New York</li>
                <li>Phone: +01 234 567 89</li>
                <li>Email: info@gmail.com</li>

            </ul>
        </div>
        <div class="foot">
            <p>© 2021 . All Rights Reserved. With love by Pathfinder Studio</p>
        </div>
    </section>
</body>
<script>
     $(document).ready(function() {
        var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
    return false;
};
        let id = getUrlParameter('id');
        var appUrl ="{{env('APP_URL')}}";
        const api_url =
        appUrl+"/owner/click_product?id="+id



// Defining async function
async function getapi(api_url) {

    // Storing response

    const response = await fetch(api_url);

    // Storing data in form of JSON
    var data = await response.json();
    console.log(data);
    if (response) {
        hideloader();
    }
    show(data);

}
// Calling that async function
getapi(api_url);
function hideloader() {
    document.getElementById('loading').style.display = 'none';
}
function show(data) {
    console.log(data.data)
    let tab ='';

    for (let r of data.data) {
     let img = r.thumbnail_image == null?"https://miro.medium.com/max/600/0*jGmQzOLaEobiNklD":r.thumbnail_image;
     tab += ` <div class="hover03"><div><figure><img src="https://mactosys.com/Report/public//images/products/${img}" height="400" width="700" alt="" class="img-thumbnail" style="height: 400px !important;"></div></div>
                <h1 class="">${r.product_name}<small class="text-muted" style="font-size: 20px;">(${r.brand})</small></h1>
                <h6>${r.product_name} services we provide include</h6>

                <p>
                ${r.product_description}
                </p>`;
 }
    // // Setting innerHTML as tab variable
     document.getElementById("product-details-data").innerHTML = tab;
}
// History Start
const api =
appUrl+"/owner/History_list/"+id;

// Defining async function
async function getapi1(url) {

    // Storing response
    const response = await fetch(url);

    // Storing data in form of JSON
    var data = await response.json();
    console.log(data);
    if (response) {
        hideloader1();
    }
    show1(data);
}
// Calling that async function
getapi1(api);
function hideloader1() {
    document.getElementById('loading').style.display = 'none';
}
function show1(data) {
    console.log(data.data)
    let tab ='';
    let count = 0;
    // Loop to access all rows
    if(data.status==true)
    {
     for (let r of data.data) {
    //    let img = r.image == null?"{{ asset('images')}}/default-profile.png":r.image;
     tab += ` <div class="vendor-name-history"><div class="images-div"><img src="http://mactosys.com/Report/public/images/default-profile.png" alt="" width="50" class="float-start rounded-circle" id="${r.vendor_id}"><small class="text-muted h5 muted">${r.vendor_name} (${r.schedule})</small></div>

                <p>${r.description}
                </p>
            </div>`;

         }
      document.getElementById("assign-history").innerHTML = tab;
         } else{
            tab += ` <div class="vendor-name-history"><div class="images-div"></div>

<p>You have no data!
</p>
</div>`;
            document.getElementById("assign-history").innerHTML = tab;
      }
}

// Vendor List Start
var appUrl ="{{env('APP_URL')}}";
const api_vendor_list =
appUrl+"/owner/get_vendor_list/"+id;

// Defining async function
async function getVendor(url) {

    // Storing response
    const response = await fetch(url);

    // Storing data in form of JSON
    var data = await response.json();
    console.log(data);

    showVendor(data);
}
// Calling that async function
getVendor(api_vendor_list);

function showVendor(data) {
    console.log(data.data)
    let tab ='';
    let count = 0;
    // Loop to access all rows
     for (let r of data.data) {

    //    let img = r.image == null?"{{ asset('images')}}/default-profile.png":r.image;
     tab += ` <div class="list-vendor"><div class="image-div"><img src="http://mactosys.com/Report/public/images/default-profile.png" alt="" width="50" class="float-start rounded-circle" id="${r.vendor_id}"><small class="text-muted h5 muted" id="vname">${r.first_name} ${r.last_name}</small> <div class="form-check">
  <input type="radio" class="form-check-input" id="radio1" name="optradio" value="${r.id}" checked>

</div></div>

                <p>Code: #D-V00${r.id}<input type="hidden" value="${r.id}" id="vid"></p>
            </div>
            </div><hr style="width:490">`;

         }
      document.getElementById("vendor-list").innerHTML = tab;
}

// ------------Add Order ---------------------//

     $('#submit-issue').click(function(){
        let pid = getUrlParameter('id');
        let vid = $('#radio1').val();
        let description = $('#description').val();
        let vname = $('#vname').text();
        let formData = new FormData();
        formData.append('product_id', pid);
        formData.append('vendor_id', vid);
        formData.append('description', description);
        formData.append('vendor_name', vname);
        formData.append('owner_id', 6);
        var appUrl ="{{env('APP_URL')}}";
        const api_url =
        appUrl+"/owner/add_order";
      let datass={
        id:pid,
        vendor_id:vid,
        description:description,
        vendor_name:vname,
        owner_id:6

      };



      let options = {
        method: 'POST',
        body: formData,
        }
// Defining async function
 getapi3(api_url, options);
async function getapi3(api_url, options) {

    // Storing response
    console.log(api_url, options);
    const response =  await fetch(api_url, options);

    // Storing data in form of JSON
    var data1 = await response.json();
   if(data1.status== true)
   {
    alert(data1.message);
    location.reload();
   }


}
// Calling that async function

});

/* --------- Vendor List---------- */
$('#vendor-search').keyup(function(){

        let search = $('#vendor-search').val();
        var appUrl ="{{env('APP_URL')}}";
        const api_url =
        appUrl+"/owner/search_vendorname?search="+search;
// Defining async function
 getsearch(api_url);
async function getsearch(api_url) {

    // Storing response

    const response =  await fetch(api_url);

    // Storing data in form of JSON
    var getdata = await response.json();
   if(getdata.status== true)
   {
    showVendor(getdata)
   console.log(getdata)
   }


}
// Calling that async function
function showVendor(data) {
    console.log(data.data)
    let tab ='';
    let count = 0;
    // Loop to access all rows
     for (let r of data.data) {

    //    let img = r.image == null?"{{ asset('images')}}/default-profile.png":r.image;
     tab += ` <div class="list-vendor"><div class="image-div"><img src="http://mactosys.com/Report/public/images/default-profile.png" alt="" width="50" class="float-start rounded-circle" id="${r.vendor_id}"><small class="text-muted h5 muted" id="vname">${r.first_name} ${r.last_name}</small> <div class="form-check">
  <input type="radio" class="form-check-input" id="radio1" name="optradio" value="${r.id}" checked>

</div></div>

                <p>Code: #D-V00${r.id}<input type="hidden" value="${r.id}" id="vid"></p>
            </div>
            </div><hr style="width:490">`;

         }
      document.getElementById("vendor-list").innerHTML = tab;
}
});

     });
</script>
</html>
