@include('layouts.header.front-end')
    <div class="blogdiv">
        <div class="btn-div">
            <h1>Blog</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam, purus sitsit amet ,<br> consectetur
                adipiscing elit ut aliquam, purus sit</p>
            <!-- <a class="box-btn">Our Services</a>
                <a class="border-btn">Contact Us </a> -->

        </div>

    </div>
    <div>

    </div>
    </div>
    <section class="services">

        <div>
            <h1 class="Product-01">Every Single Update
                <br>Story From Our Journal
            </h1>
        </div>
        <div class="blog-img-main">
            <div class="blog-img">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-01">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-02">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
        </div>
        <div class="blog-img-main">
            <div class="blog-img">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-01">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-02">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
        </div>
        <div class="blog-img-main">
            <div class="blog-img">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-01">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-02">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
        </div>
        <div class="blog-img-main">
            <div class="blog-img">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-01">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-02">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
        </div>
        <div class="blog-img-main">
            <div class="blog-img">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-01">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-02">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
        </div>
        <div class="blog-img-main">
            <div class="blog-img">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-01">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
            <div class="blog-img-02">
                <h5>13 Nov</h5>
                <h4>Excepteur sint occaecat
                    <br>cupidatat non proident
                </h4>
            </div>
        </div>





        </div>

    </section>
    <section class="footers">

        <div class="footer-first-div">
            <h1>LOGO</h1>
            <p>The world’s first and largest digital marketplace for crypto <br> collectibles and non-fungible tokens
                (NFTs).
                Buy, sell, and <br> discover exclusive digital assets. Ut enim ad minima veniam, quis <br> nostrum
                exercitationem
                ullam corporis suscipit laboriosam, nisi ut <br> aliquid ex ea commodi consequatur</p>
            <h6>Call Us:</h6>
            <h4 style="color: #6759FF;">
                +01 234 567 89
            </h4>
        </div>
        <div class="footer-second-div">

            <ul>

                <li style="font-family: 'Lato'sans-serif;
                   font-style: normal;
                   font-weight: 700;
                   font-size: 20px;
                   color: #6759FF;"> Menu Links</li>

                <li>Home </li>
                <li>Service</li>
                <li>About US </li>
                <li>Tarot Cards</li>
                <li>Blog</li>
            </ul>
        </div>
        <div class="footer-third-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                    font-style: normal;
                    font-weight: 700;
                    font-size: 20px;
                    color: #6759FF;"> Services</li>

                <li>Blog</li>
                <li>Refrigerator</li>
                <li>Mobile</li>
                <li>Laptop</li>
                <li>Blender</li>
                <li>Air purifier</li>
            </ul>
        </div>
        <div class="footer-four-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                    font-style: normal;
                    font-weight: 700;
                    font-size: 20px;
                    color: #6759FF;"> Contact info</li>

                <li>Collarado Demos
                    Beach, <br> New York</li>
                <li>Phone: +01 234 567 89</li>
                <li>Email: info@gmail.com</li>

            </ul>
        </div>
        <div class="foot">
            <p>© 2021 . All Rights Reserved. With love by Pathfinder Studio</p>
        </div>
    </section>
</body>

</html>
