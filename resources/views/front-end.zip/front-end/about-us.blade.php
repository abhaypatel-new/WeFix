@include('layouts.header.front-end')
    <div class="maindiv">
        <div class="btn-div">
            <h1>About Us</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam, purus sitsit amet <br>, consectetur
                adipiscing elit ut aliquam, purus sit</p>
            <!-- <a class="box-btn">Our Services</a>
                <a class="border-btn">Contact Us </a> -->

        </div>

    </div>
    <div>

    </div>
    </div>
    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>ABOUT COMPANY </h3>
            </div>
        </div>
    </div>

    <div class="about-img">
        <img src="{{ asset('images')}}/image/WE Are.jpg" alt="" width="527px" height="466px">
        <div class="we-are-text">
            <h1 class="we-are-text-h1">WE ARE MOST POPULAR <br>REPAIR WE FIX </h1>
            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil
                <br> impedit quo minus id quod maxime placeat facere possimus, omnis
                <br> voluptas assumenda est, omnis dolor repellendus,
            </p>
            <div class="row">
                <div class="we-are-main-01">
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            80
                        </h2>
                        <h5 class="we-are-text-h5">
                            Member
                            <br> Professional
                        </h5>
                    </div>
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            44
                        </h2>
                        <h5 class="we-are-text-h5">
                            Total
                            <br> Branches
                        </h5>
                    </div>
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            12
                        </h2>
                        <h5 class="we-are-text-h5">
                            Project
                            <br>Complated
                        </h5>
                    </div>
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            50
                        </h2>
                        <h5 class="we-are-text-h5">
                            Client
                            <br> Satisfaction
                        </h5>
                    </div>
                </div>
            </div>
            <button class="about-button">Learn More</button>
        </div>
    </div>
    </div>



    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>TESTIMONIALS</h3>
            </div>
        </div>
    </div>
    <div>
        <h1 class="Product-01">What Clients Says</h1>
    </div>
    <div class="TESTIMONIALS-card-main">
        <div class="TESTIMONIALS-card">
            <img class="TESTIMONIALS-card-png" src="{{ asset('images')}}/image/TESTIMONIALS-card-png.jpg" alt="">
            <p>On the other hand, we denounce with <br> righteous indignation and dislike men who <br> are so beguiled
                and.
            </p>
            <div class="border-div"></div>
            <div class="TESTIMONIALS-card-02">
                <img src="{{ asset('images')}}/image/TESTIMONIALS.jpg" alt="" width="65" height="65">
                <div>
                    <h5 class="TESTIMONIALS-card-02-01">Serhiy Hipskyy</h5>
                    <p class="TESTIMONIALS-card-02-02">CEO Universal</p>
                </div>
            </div>
        </div>
        <div class="TESTIMONIALS-card">
            <img class="TESTIMONIALS-card-png" src="{{ asset('images')}}/image/TESTIMONIALS-card-png.jpg" alt="">
            <p>On the other hand, we denounce with <br> righteous indignation and dislike men who <br> are so beguiled
                and.
            </p>
            <div class="border-div"></div>
            <div class="TESTIMONIALS-card-02">
                <img src="{{ asset('images')}}/image/TESTIMONIALS.jpg" alt="" width="65" height="65">
                <div>
                    <h5 class="TESTIMONIALS-card-02-01">Serhiy Hipskyy</h5>
                    <p class="TESTIMONIALS-card-02-02">CEO Universal</p>
                </div>
            </div>
        </div>
        <div class="TESTIMONIALS-card">
            <img class="TESTIMONIALS-card-png" src="{{ asset('images')}}/image/TESTIMONIALS-card-png.jpg" alt="">
            <p>On the other hand, we denounce with <br> righteous indignation and dislike men who <br> are so beguiled
                and.
            </p>
            <div class="border-div"></div>
            <div class="TESTIMONIALS-card-02">
                <img src="{{ asset('images')}}/image/TESTIMONIALS.jpg" alt="" width="65" height="65">
                <div>
                    <h5 class="TESTIMONIALS-card-02-01">Serhiy Hipskyy</h5>
                    <p class="TESTIMONIALS-card-02-02">CEO Universal</p>
                </div>
            </div>
        </div>
    </div>
    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>TEAM</h3>
            </div>
        </div>
    </div>
    <div>
        <h1 class="Product-01">Meet Our Team</h1>
    </div>
    <div class="tema-card-all">
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Mary Walden.jpg" alt="" width="220px" height="260px">
            <h5>Mary Walden</h5>
            <h6>Technician</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Brooklyn Simmons.jpg" alt="" width="220px" height="260px">
            <h5>Brooklyn Simmons</h5>
            <h6>Project Manager</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Yun Sanchez.jpg" alt="" width="220px" height="260px">
            <h5>Yun Sanchez</h5>
            <h6>Founder & CEO</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/James Lopez.jpg" alt="" width="220px" height="260px">
            <h5>James Lopez</h5>
            <h6>Technician</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Mary Walden01.jpg" alt="" width="220px" height="260px">
            <h5>Mary Walden</h5>
            <h6>Technician</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
    </div>



    <section class="footers">

        <div class="footer-first-div">
            <h1>LOGO</h1>
            <p>The world’s first and largest digital marketplace for crypto <br> collectibles and non-fungible tokens
                (NFTs).
                Buy, sell, and <br> discover exclusive digital assets. Ut enim ad minima veniam, quis <br> nostrum
                exercitationem
                ullam corporis suscipit laboriosam, nisi ut <br> aliquid ex ea commodi consequatur</p>
            <h6>Call Us:</h6>
            <h4 style="color: #6759FF;">
                +01 234 567 89
            </h4>
        </div>
        <div class="footer-second-div">

            <ul>

                <li style="font-family: 'Lato'sans-serif;
                   font-style: normal;
                   font-weight: 700;
                   font-size: 20px;
                   color: #6759FF;"> Menu Links</li>

                <li> <a href="./index.html">Home</a> </li>
                <li><a href="./service.html">Service</a></li>
                <li>About US </li>
                <li>Tarot Cards</li>
                <li>Blog</li>
            </ul>
        </div>
        <div class="footer-third-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                    font-style: normal;
                    font-weight: 700;
                    font-size: 20px;
                    color: #6759FF;"> Services</li>

                <li>Blog</li>
                <li>Refrigerator</li>
                <li>Mobile</li>
                <li>Laptop</li>
                <li>Blender</li>
                <li>Air purifier</li>
            </ul>
        </div>
        <div class="footer-four-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                    font-style: normal;
                    font-weight: 700;
                    font-size: 20px;
                    color: #6759FF;"> Contact info</li>

                <li>Collarado Demos
                    Beach, <br> New York</li>
                <li>Phone: +01 234 567 89</li>
                <li>Email: info@gmail.com</li>

            </ul>
        </div>
        <div class="foot">
            <p>© 2021 . All Rights Reserved. With love by Pathfinder Studio</p>
        </div>
    </section>
</body>

</html>
