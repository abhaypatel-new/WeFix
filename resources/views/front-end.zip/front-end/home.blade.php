
    @include('layouts.header.front-end')

    <div class="homediv">
        <div class="btn-div">
            <h1>Best Repair Services For <br> WE FIX </h1>
            <!-- <a class="box-btn">Our Services</a>
                <a class="border-btn">Contact Us </a> -->
            <button type="button" class="buttonmain">Our Service</button>
            <button type="button" class="buttontwo">Contact Us</button>
        </div>
    </div>
    <div>
        <div>
            <div class="container">

                <div class="align-div">
                    <div class="single-feature text-center">
                        <div class="feature-icon">
                            <div class="img-div">
                                <img src="{{ asset('images') }}/image/Repairing Service icon.png" alt="" height="50px" width="50px">
                            </div>
                        </div>
                        <div class="feature-content">
                            <h4>Repaired and Enjoy</h4>
                        </div>
                        <div class="feature-content-descripcetion">
                            <p>There are many variations of
                                passages available but the
                                majority have suffered alter
                                humour</p>
                        </div>
                    </div>
                    <div class="single-feature text-center">
                        <div class="feature-icon">
                            <div class="img-div">
                                <img src="{{ asset('images') }}/image/Repairing Service icon.png" alt="" height="50px" width="50px">
                            </div>
                        </div>
                        <div class="feature-content">
                            <h4>Repairing Service</h4>
                        </div>
                        <div class="feature-content-descripcetion">
                            <p>There are many variations of
                                passages available but the
                                majority have suffered alter
                                humour</p>
                        </div>
                    </div>
                    <div class="single-feature text-center">
                        <div class="feature-icon">
                            <div class="img-div">
                                <img src="{{ asset('images') }}/image/Repairing Service icon.png" alt="" height="50px" width="50px">
                            </div>
                        </div>
                        <div class="feature-content">
                            <h4>Online Scheduling</h4>
                        </div>
                        <div class="feature-content-descripcetion">
                            <p>There are many variations of
                                passages available but the
                                majority have suffered alter
                                humour</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>ABOUT COMPANY </h3>
            </div>
        </div>
    </div>

    <div class="about-img">
        <img src="{{ asset('images')}}/image/WE Are.jpg" alt="" width="527px" height="466px">
        <div class="we-are-text">
            <h1 class="we-are-text-h1">WE ARE MOST POPULAR <br>REPAIR WE FIX </h1>
            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil
                <br> impedit quo minus id quod maxime placeat facere possimus, omnis
                <br> voluptas assumenda est, omnis dolor repellendus,
            </p>
            <div class="row we-are">
                <div class="we-are-main-01">
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            80
                        </h2>
                        <h5 class="we-are-text-h5">
                            Member
                            <br> Professional
                        </h5>
                    </div>
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            44
                        </h2>
                        <h5 class="we-are-text-h5">
                            Total
                            <br> Branches
                        </h5>
                    </div>
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            12
                        </h2>
                        <h5 class="we-are-text-h5">
                            Project
                            <br>Complated
                        </h5>
                    </div>
                    <div class="we-are-main">
                        <h2 class="we-are-text-h2">
                            50
                        </h2>
                        <h5 class="we-are-text-h5">
                            Client
                            <br> Satisfaction
                        </h5>
                    </div>
                </div>
            </div>
            <button class="about-button">Learn More</button>
        </div>
    </div>
    </div>
    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>OUR SERVICES</h3>
            </div>
        </div>
    </div>
    <div>
        <h1 class="Product-01">All Our Product</h1>
    </div>
    <div class="d-flex justify-content-center">
            <div class="spinner-border"
                 role="status" id="loading">
                <span class="sr-only">Loading...</span>
            </div>
        </div>


    <section class="scrollerContainer ">

    <!-- <div class="Product-card-all" id="product-list">


</div> -->
<div class="carousel-slider">
<button class="carousel-slider-button" style="background-color: #6759FF;"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
</div>
</section>
<!-- <div class="carousel-slider">
<section class="scrollerContainer">
        <button class="carousel-slider-button" style="background-color: #6759FF;"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
    </div> -->
    <div class="Get-a-discount">
        <img src="{{ asset('images')}}/image/Get-a-discount.png" alt="" height="400" width="100%">
        <img src="{{ asset('images')}}/image/young-electrician-man.png" alt="" width="560" height="400" style="margin-left: 700px;">
        <div>
            <h2>Get a discount for new users</h2>
            <h1>25% OFF</h1>
            <h4>Get 25% discount for shipping cost</h4>
        </div>
    </div>
    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>TESTIMONIALS</h3>
            </div>
        </div>
    </div>
    <div>
        <h1 class="Product-01">What Clients Says</h1>
    </div>
    <div class="TESTIMONIALS-card-main">
        <div class="TESTIMONIALS-card">
            <img class="TESTIMONIALS-card-png" src="{{ asset('images')}}/image/TESTIMONIALS-card-png.jpg" alt="">
            <p>On the other hand, we denounce with <br> righteous indignation and dislike men who <br> are so beguiled
                and.
            </p>
            <div class="border-div"></div>
            <div class="TESTIMONIALS-card-02">
                <img src="{{ asset('images')}}/image/TESTIMONIALS.jpg" alt="" width="65" height="65">
                <div>
                    <h5 class="TESTIMONIALS-card-02-01">Serhiy Hipskyy</h5>
                    <p class="TESTIMONIALS-card-02-02">CEO Universal</p>
                </div>
            </div>
        </div>
        <div class="TESTIMONIALS-card">
            <img class="TESTIMONIALS-card-png" src="{{ asset('images')}}/image/TESTIMONIALS-card-png.jpg" alt="">
            <p>On the other hand, we denounce with <br> righteous indignation and dislike men who <br> are so beguiled
                and.
            </p>
            <div class="border-div"></div>
            <div class="TESTIMONIALS-card-02">
                <img src="{{ asset('images')}}/image/TESTIMONIALS.jpg" alt="" width="65" height="65">
                <div>
                    <h5 class="TESTIMONIALS-card-02-01">Serhiy Hipskyy</h5>
                    <p class="TESTIMONIALS-card-02-02">CEO Universal</p>
                </div>
            </div>
        </div>
        <div class="TESTIMONIALS-card">
            <img class="TESTIMONIALS-card-png" src="{{ asset('images')}}/image/TESTIMONIALS-card-png.jpg" alt="">
            <p>On the other hand, we denounce with <br> righteous indignation and dislike men who <br> are so beguiled
                and.
            </p>
            <div class="border-div"></div>
            <div class="TESTIMONIALS-card-02">
                <img src="{{ asset('images')}}/image/TESTIMONIALS.jpg" alt="" width="65" height="65">
                <div>
                    <h5 class="TESTIMONIALS-card-02-01">Serhiy Hipskyy</h5>
                    <p class="TESTIMONIALS-card-02-02">CEO Universal</p>
                </div>
            </div>
        </div>
    </div>
    <div class="about-main">
        <div class="module-border-wrap">
            <div class="body-about">
                <h3>TEAM</h3>
            </div>
        </div>
    </div>
    <div>
        <h1 class="Product-01">Meet Our Team</h1>
    </div>
    <div class="tema-card-all">
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Mary Walden.jpg" alt="" width="220px" height="260px">
            <h5>Mary Walden</h5>
            <h6>Technician</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Brooklyn Simmons.jpg" alt="" width="220px" height="260px">
            <h5>Brooklyn Simmons</h5>
            <h6>Project Manager</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Yun Sanchez.jpg" alt="" width="220px" height="260px">
            <h5>Yun Sanchez</h5>
            <h6>Founder & CEO</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/James Lopez.jpg" alt="" width="220px" height="260px">
            <h5>James Lopez</h5>
            <h6>Technician</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
        <div class="tema-card">
            <img src="{{ asset('images')}}/image/Mary Walden01.jpg" alt="" width="220px" height="260px">
            <h5>Mary Walden</h5>
            <h6>Technician</h6>
            <p>On the other hand, we denounce <br> righteous indignation and dislike <br>
                are so beguiled and. </p>
        </div>
    </div>
    <div class="about-main">
                <div class="module-border-wrap">
            <div class="body-about">
                <h3>OUR BLOG</h3>
            </div>
        </div>
    </div>
    <div>
        <h1 class="Product-01">Every Single Update
            <br>Story From Our Journal
        </h1>
    </div>
    <div class="blog-img-main">
        <div class="blog-img">
            <h5>13 Nov</h5>
            <h4>Excepteur sint occaecat
                <br>cupidatat non proident
            </h4>
        </div>
        <div class="blog-img-01">
            <h5>13 Nov</h5>
            <h4>Excepteur sint occaecat
                <br>cupidatat non proident
            </h4>
        </div>
        <div class="blog-img-02">
            <h5>13 Nov</h5>
            <h4>Excepteur sint occaecat
                <br>cupidatat non proident
            </h4>
        </div>
    </div>
    <div class="carousel-slider">
        <button class="carousel-slider-button" style="background-color: #6759FF;"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
        <button class="carousel-slider-button"></button>
    </div>
    <section class="footers">

        <div class="footer-first-div">
            <h1>LOGO</h1>
            <p>The world’s first and largest digital marketplace for crypto <br> collectibles and non-fungible tokens
                (NFTs).
                Buy, sell, and <br> discover exclusive digital assets. Ut enim ad minima veniam, quis <br> nostrum
                exercitationem
                ullam corporis suscipit laboriosam, nisi ut <br> aliquid ex ea commodi consequatur</p>
            <h6>Call Us:</h6>
            <h4 style="color: #6759FF;">
                +01 234 567 89
            </h4>
        </div>
        <div class="footer-second-div">

            <ul>

                <li style="font-family: 'Lato'sans-serif;
                   font-style: normal;
                   font-weight: 700;
                   font-size: 20px;
                   color: #6759FF;"> Menu Links</li>

                <li>Home </li>
                <li>Service</li>
                <li>About US </li>
                <li>Tarot Cards</li>
                <li>Blog</li>
            </ul>
        </div>
        <div class="footer-third-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                    font-style: normal;
                    font-weight: 700;
                    font-size: 20px;
                    color: #6759FF;"> Services</li>

                <li>Blog</li>
                <li>Refrigerator</li>
                <li>Mobile</li>
                <li>Laptop</li>
                <li>Blender</li>
                <li>Air purifier</li>
            </ul>
        </div>
        <div class="footer-four-div">
            <ul>
                <li style="font-family: 'Lato'sans-serif;
                    font-style: normal;
                    font-weight: 700;
                    font-size: 20px;
                    color: #6759FF;"> Contact info</li>

                <li>Collarado Demos
                    Beach, <br> New York</li>
                <li>Phone: +01 234 567 89</li>
                <li>Email: info@gmail.com</li>

            </ul>
        </div>
        <div class="foot">
            <p>© 2021 . All Rights Reserved. With love by Pathfinder Studio</p>
        </div>
    </section>
</body>

<script>


     $(document).ready(function() {
        var appUrl ="{{env('APP_URL')}}";

        const api_url =
        appUrl+"/owner/get_all_product";

// Defining async function
async function getapi(url) {

    // Storing response
    const response = await fetch(url);

    // Storing data in form of JSON
    var data = await response.json();
    console.log(data);
    if (response) {
        hideloader();
    }
    show(data);
}
// Calling that async function
getapi(api_url);
function hideloader() {
    document.getElementById('loading').style.display = 'none';
}
function show(data) {
    console.log(data.data)
    let tab ='';
    let count = 0;
    // Loop to access all rows
    for (let r of data.data) {
        let img = r.thumbnail_image == null?"https://miro.medium.com/max/600/0*jGmQzOLaEobiNklD":r.thumbnail_image;
         tab += ` <article><a href="./product-details?id=${r.id}" style="text-decoration: none;"><div class="Product-cards caption">
            <img src="${img}" alt="" width="150px" height="150px" class="rounded id="${r.id}">
            <h2 >${r.brand}</h2>
            <h3><span style="display:inline-block;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;max-width: 13ch; color:#008080">${r.product_name}</span></h3>
            <p><span style="display:inline-block;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;max-width: 13ch;color:#808080; font-size:14px;" >${r.product_description}</span></p>
        </div></a> </article>`;
        count = count+1;
      if(count == 10){
       break;
       return false;
      }
    }
    // Setting innerHTML as tab variable
    // document.getElementById("product-list").innerHTML = tab;
      // Number of items viewable at one time
var scrollerItemsViewable = 5;
// Scroller speed in seconds
var scrollerSpeed = 5;
// Transition speed - must be <= scrollerSpeed
var scrollerTransitionSpeed = 4;

// Rebuild the element list to remove white space
var scrollerItemsEl = '';
$('.scrollerContainer > article').each(function(index) {
  //console.log( index + ": " + $( this ).text() );
  scrollerItemsEl += $(this).prop('outerHTML');
});
$('.scrollerContainer').html(tab);

// Wrap items in a box that is as wide as the all the elements combined.
// This prevents the items from wrapping if wider than the scroller width
$('.scrollerContainer > article').wrapAll('<div class="scrollerGroup" />');
var scrollerCount = $('.scrollerContainer .scrollerGroup > article').length;
var scrollerItemWidth = parseInt($('.scrollerContainer').css('width')) / scrollerItemsViewable;
$('.scrollerContainer .scrollerGroup > article').css('width', scrollerItemWidth + 'px');
$('.scrollerContainer .scrollerGroup').css('width',scrollerCount * scrollerItemWidth + 'px');
$('.scrollerContainer .scrollerGroup > article').css('transition', 'margin ' + scrollerTransitionSpeed + 's');

// Set Starting Values
var scrollerLeftMargin = '-' + scrollerItemWidth + 'px';
var scrollerFirstItem = true;

scrollerAnimate(scrollerSpeed);

function scrollerAnimate(speed) {
  setInterval(scrollerRotate, speed * 1000);
}

function scrollerRotate() {
  if (scrollerFirstItem) {
    scrollerFirstItem = false;
  } else {
    $('.scrollerContainer .scrollerGroup').append($('.scrollerContainer .scrollerGroup article:first-child'));
  }
  $('.scrollerContainer .scrollerGroup > article').css('margin-left', '0');
  $('.scrollerContainer .scrollerGroup > article:first-child').css('margin-left', scrollerLeftMargin);
}

}


     });
     $(".navbar-toggler").click(function () {

$header = $(this);
//getting the next element
$content = $header.next();
//open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
$content.slideToggle(500, function () {
    //execute this after slideToggle is done
    //change text of header based on visibility of content div
    $header.text(function () {
        //change text based on condition
        return $content.is(":visible") ? "Collapse" : "Expand";
    });
});

});

</script>
</html>
